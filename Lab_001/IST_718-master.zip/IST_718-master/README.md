# IST_718
Basic Repository for 2SU Version of IST 718

This is the top level repo for the 2SU Version of IST 718.

We will have a total of five repos for the course:

1 - IST 718 - Top level - for new stuff and experimental work

2 - Block1_Crawl - materials for weeks 1, 2, 3

3 - Block2_Walk - materials for weeks 4, 5, 6

4 - Block3_Run - materials for weeks 7, 8, 9

5 - Data - assorted data files for the course

Please let me know if you have questions - jmfox01@syr.edu
